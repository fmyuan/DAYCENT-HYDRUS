% Generating a new crop100 file for DailyDayCent

% By Fugen Dou, Texas AgriLife at Beaumont
% September 25, 2011

function [cropparameter] = Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop, cropjjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile)
% InitialCrop100File: This is the initial crop file which will be modified by this DAYCENT_crop100.m function. 
% ObjectCrop: the abbreviated name of the crop used in crop.100 which you want to make a change.
% NumOfTotalCropPar: number of total crop parameters used in crop.100 file
% ParOfCropToChange: parameter of the crop which will be modified.
% ModifedValueOfCropPar: to be modified value of the crop parameter.
% blanks(12-numel(num2str(fix(ModifedValueOfCropPar))))]): Used to created a fixed position output display.

% Sample: DAYCENT_crop100('crop100.txt', 'KNZ', 108, 2, 77, 'crop1080.100')
% Sample: Crop100ForDailyDC('testing', 'crop100.txt', 'KNZ', 108, 2, 77, 'crop1080.100')
%switchcondition = 'change parameters';

%cropparameter = ModifedValueOfCropPar;

switch crop100modification

  case 'change some parameters'
    
        fid2 = fopen(InitialCrop100File); % Open this file to modify for crop.100 file

        fid4 = fopen(TargertCropFile,'w'); % To create a new crop100 text file for DailyDayCent.

        while(~feof(fid2))% To test whether it is the end of the file
             %CropNameA=textscan(fid2, '%s',1, 'delimiter','\r'); % Only read one whole line (row)
             %CropNameA=textscan(fid2, '%s',1); % Only read one whole line (row)
             CropNameA = textscan(fid2, '%s',1); % Only read one whole line (row)
             CropFullName = textscan(fid2, '%s',1, 'delimiter','\r'); % Only read one whole line (row)
             CropName=char(CropNameA{1,1});
             CropFullName =char(CropFullName{1,1});
             
             disp(['the listed crop full name: ' CropFullName]);
             disp(['the listed crop abbrev name: ' CropName]);

            if (~isempty(CropName))
               fprintf(fid4,'%s\r\n',[CropName blanks(5) CropFullName]);
               

               % you have to change the following to create an effective Crop name for strcmp
               %CropName = CropName(1,1:2);
               %CropName = CropName(1,:);
               if (~strcmp(CropName, ObjectCrop))% To determine whether it is the objective crop to be modified
                   %disp(['the listed crop name:' CropName])
                   for j = 1:NumOfTotalCropPar % NumOfTotalCropPar: number of total crop parameters used in crop.100 file
                      
                           numvalue=textscan(fid2,'%f',1);% Read the value of the parameter
                           numvalue =cell2mat(numvalue);
                           strvalueB=textscan(fid2,'%s',1);
                           strvalue=char(strvalueB{1});
                           fprintf(fid4,'%s',[num2str(numvalue,'%6.5f') blanks(12-numel(num2str(fix(numvalue))))]); 
                           fprintf(fid4,'%s\r\n',strvalue);

                   end
                   
               else
                   
                                  
                   for j = 1:NumOfTotalCropPar % NumOfTotalCropPar: number of total crop parameters used in crop.100 file
                       if j == ParOfCropToChange % NumOfCropParToChange: 
                           numvalue=textscan(fid2,'%f',1);% Read the value of the parameter
                           numvalue =cell2mat(numvalue);
                           strvalueB=textscan(fid2,'%s',1);
                           strvalue=char(strvalueB{1});
                           fprintf(fid4,'%s',[num2str(ModifedValueOfCropPar,'%6.5f') blanks(12-numel(num2str(fix(ModifedValueOfCropPar))))]);
                           fprintf(fid4,'%s\r\n',strvalue);
                           disp(['parameter to be modified: ' ModifedValueOfCropPar])

                       else
                           numvalue=textscan(fid2,'%f',1);% Read the value of the parameter
                           numvalue =cell2mat(numvalue);
                           strvalueB=textscan(fid2,'%s',1);
                           strvalue=char(strvalueB{1});
                           fprintf(fid4,'%s',[num2str(numvalue,'%6.5f') blanks(12-numel(num2str(fix(numvalue))))]); 
                           fprintf(fid4,'%s\r\n',strvalue);


                       end
                   end
               end
            end
        end

        fclose(fid2);
        fclose(fid4);

        fid5 = fopen(TargertCropFile);

        fid6 = fopen(InitialCrop100File, 'w');

        while(~feof(fid5))% To test whether it is the end of the file
             CropNameA=textscan(fid5, '%s',1, 'delimiter','\r'); % Only read one whole line (row)
             CropName=char(CropNameA{1,1});

            if (~isempty(CropName))
               fprintf(fid6,'%s\r\n',[CropName blanks(5)]);

                   for j = 1:NumOfTotalCropPar % NumOfTotalCropPar: number of total crop parameters used in crop.100 file

                           numvalue=textscan(fid2,'%f',1);% Read the value of the parameter
                           numvalue =cell2mat(numvalue);
                           strvalueB=textscan(fid2,'%s',1);
                           strvalue=char(strvalueB{1});
                           fprintf(fid6,'%s',[num2str(numvalue,'%6.5f') blanks(12-numel(num2str(fix(numvalue))))]); 
                           fprintf(fid6,'%s\r\n',strvalue);
                   end
            end
        end

        fclose(fid5);
        fclose(fid6);
        
             
    case 'add a new crop' 
        
        fid2 = fopen(InitialCrop100File, 'a'); % Open this file to modify for crop.100 file

        %fid4 = fopen(TargertCropFile,'w'); % To create a new crop100 text file for DailyDayCent.
        CropName = ObjectCrop{3,(cropjjj+2)};
        CropFullName = ObjectCrop{2,(cropjjj+2)};
        
        fprintf(fid2,'%s\r\n',[CropName blanks(5) CropFullName]);
        
        for j = 1:NumOfTotalCropPar % NumOfTotalCropPar: number of total crop parameters used in crop.100 file
           
               ModifedValueOfCropPar = ObjectCrop{(j+3),(cropjjj+2)};
               disp(['Is this a str:  ' ModifedValueOfCropPar]);
               strvalue = ObjectCrop{(j+3),1};
               fprintf(fid2,'%s',[num2str(ModifedValueOfCropPar,'%6.5f') blanks(12-numel(num2str(fix(ModifedValueOfCropPar))))]);
               fprintf(fid2,'%s\r\n',strvalue);
               disp(['parameter to be modified: ' ModifedValueOfCropPar])

        end
       
    otherwise
           
           
        
            
 end


%
%--------------------------------------------------------------------------
% Copy and create a file contain only the crop which you specify, for example, corn
% copy a new crop file to avoid any impact on crop.100 created
copyfile('crop.100', 'copyofcrop100.txt', 'f');
cropparameter = [];
fid6 = fopen('copyofcrop100.txt'); % Open this file to modify for crop.100 file

fid7 = fopen('newlycreatedcropparameter.txt','w'); % To create a new crop100 text file for DailyDayCent.

while(~feof(fid6))% To test whether it is the end of the file
    CropNameA = textscan(fid6, '%s',1); % Only read one whole line (row)
    CropFullName = textscan(fid6, '%s',1, 'delimiter','\r'); % Only read one whole line (row)
    CropName=char(CropNameA{1,1});
    CropFullName =char(CropFullName{1,1});
    
    disp(['the listed crop full name: ' CropFullName]);
    disp(['the listed crop abbrev name: ' CropName]);
    
    if (~isempty(CropName))
        %fprintf(fid7,'%s\r\n',[CropName blanks(5) CropFullName]);
        
        
        % you have to change the following to create an effective Crop name for strcmp
        %CropName = CropName(1,1:2);
        %CropName = CropName(1,:);
        if (~strcmp(CropName, ObjectCrop))% To determine whether it is the objective crop to be modified
            %disp(['the listed crop name:' CropName])
            for j = 1:NumOfTotalCropPar % NumOfTotalCropPar: number of total crop parameters used in crop.100 file
                
                numvalue=textscan(fid6,'%f',1);% Read the value of the parameter
                numvalue =cell2mat(numvalue);
                strvalueB=textscan(fid6,'%s',1);
                strvalue=char(strvalueB{1});
                %fprintf(fid7,'%s',[num2str(numvalue,'%6.5f') blanks(12-numel(num2str(fix(numvalue))))]);
                %fprintf(fid7,'%s\r\n',strvalue);
                
            end
            
        else
            
            
            for j = 1:NumOfTotalCropPar % NumOfTotalCropPar: number of total crop parameters used in crop.100 file
                if j == ParOfCropToChange % NumOfCropParToChange:
                    numvalue=textscan(fid6,'%f',1);% Read the value of the parameter
                    numvalue =cell2mat(numvalue);
                    strvalueB=textscan(fid6,'%s',1);
                    strvalue=char(strvalueB{1});
                    fprintf(fid7,'%s\r\n',[num2str(ModifedValueOfCropPar,'%6.5f') blanks(12-numel(num2str(fix(ModifedValueOfCropPar))))]);
                    %fprintf(fid7,'%s\r\n',strvalue);
                    %disp(['parameter to be modified: ' ModifedValueOfCropPar])
                    
                else
                    numvalue=textscan(fid6,'%f',1);% Read the value of the parameter
                    numvalue =cell2mat(numvalue);
                    strvalueB=textscan(fid6,'%s',1);
                    strvalue=char(strvalueB{1});
                    fprintf(fid7,'%s\r\n',[num2str(numvalue,'%6.5f') blanks(12-numel(num2str(fix(numvalue))))]);
                    %fprintf(fid7,'%s\r\n',strvalue);                    
                                     
                    
                end
                
                cropparameter = [cropparameter numvalue];
                
            end
        end
    end
end

fclose(fid6);
fclose(fid7);

delete('copyofcrop100.txt');
delete('newlycreatedcropparameter.txt');







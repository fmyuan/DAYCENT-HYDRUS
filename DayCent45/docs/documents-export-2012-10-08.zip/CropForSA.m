% Generating a new set of input data files to run DailyDayCent model

% By Fugen Dou, Texas AgriLife at Beaumont
% September 25, 2011


function  [cropparameter] = CropForSA(ObjectCrop, crop100modification, cropjjj, DateRange)
PathOfExcelDataFile = 'C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab';
ExcelDataFile = 'InPutDataForDDC.xls';
% Input1: 

% Input data files (17) for driving DailyDayCent Model includes: 
% crop.100 ; cult.100;  site.100 ; site.sch ; fert.100 ; fire.100 ;
% fix.100 ;  graz.100 ; harv.100 ; irri.100 ; omad.100 ; tree.100 ;
% trem.100 ; site.wth ;
% outfiles.in ; sitepar.in ; soils.in
% Example: CropForSA('SORG', 'change some parameters', 12, DateRange)
    
 
%*****Create a new crop.100 fiel for optimization purpose by Dou on Sept 10, 2012*******************
% To identify whether there is the same crop used in the crop.100 file: 
NumOfTotalCropPar= 108;

switch crop100modification
    
    case 'change some parameters'
        
        % copy a new crop file to avoid any impact on crop.100 created
        %copyfile('crop.100', 'copyofInitialcrop100.txt', 'f');
        InitialCrop100File = 'copyofInitialcrop100.txt';
        MatrixOfParameterToBeModified = DateRange;            
        TargertCropFile = 'crop.100'; 
        
        ParOfCropToChange = MatrixOfParameterToBeModified(1, 1);
        ModifedValueOfCropPar = MatrixOfParameterToBeModified(1, 2);
        
        [cropparameter] = Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop,cropjjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
        
        
        %delete('copyofInitialcrop100.txt');
        
    case 'add a new crop'
        
        InitialCrop100File = 'crop.100';
        ExcelSheet = 'crop';
        DateRange = 'F1:AV111';
        [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRange);
        MatrixOfParameterToBeModified = num;
        ObjectCrop = raw;
        
        disp(MatrixOfParameterToBeModified);
        disp(size(MatrixOfParameterToBeModified));
        disp(txt);
        disp(size(txt));
        disp(raw);
        disp(size(raw));
        TargertCropFile = 'cropuseless.txt'; %which one will not be used
        
        %for i = 1:length(MatrixOfParameterToBeModified)
        ParOfCropToChange = MatrixOfParameterToBeModified(1, 1);%which one will not be used
        ModifedValueOfCropPar = MatrixOfParameterToBeModified(1, cropjjj);%which one will not be used
        %Crop100ForDailyDC(InitialCrop100File, ObjectCrop, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
        Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop, cropjjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
        %end
        
    otherwise
        
        disp('Crop.100: using the existed crop.100');
        num = 123;
        txt = 'using the existed crop.100';
        raw = 999;
        
end
        

%**************************************************************************



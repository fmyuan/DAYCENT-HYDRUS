% Run DailyDayCent model and get the outputs

% By Fugen Dou, Texas A&M AgriLife at Beaumont
% September 14, 2012

function [abgbiomass, biomassdata_FigureB] = DDCOutput(RunName, stime, etime) 


% Extract output files using DailyDayCent_list100
dos 'DailyDayCent_list100 example Cstock Cstocklist.txt';
dos 'DailyDayCent_list100 example Nstock Nstocklist.txt';
dos 'DailyDayCent_list100 example Cflow  Cflowlist.txt';
dos 'DailyDayCent_list100 example Nflow  Nflowlist.txt';
disp('I am ok3');


% save ascii-format outputs (daily)
    if(exist('daily.out','file')==2)
        FileTruncating('daily.out', [RunName '_PET.dat'], 1, stime, etime);
    end
    
    if(exist('summary.out','file')==2)
        %FileTruncating('summary.out', [RunName '_wthghg.dat'], 1, stime, etime);
    end
    
    if(exist('nflux.out','file')==2)
        FileTruncating('nflux.out',   [RunName '_nflux.dat'], 1, stime, etime);
    end
    
    if(exist('cflux.out','file')==2)
        FileTruncating('cflux.out',   [RunName '_cflux.dat'], 1, stime, etime);
    end
        
    if(exist('soiln.out','file')==2)
        FileTruncating('soiln.out',     [RunName '_soiln.dat'], 1, stime, etime);
    end
    
    if(exist('soiltavg.out','file')==2)
        FileTruncating('soiltavg.out',  [RunName '_soilt.dat'], 1, stime, etime);
    end
    
    if(exist('vswc.out','file')==2)
        FileTruncating('vswc.out',      [RunName '_soilwv.dat'], 1, stime, etime);
    end
    
    if(exist('swp.out','file')==2)
        FileTruncating('swp.out',      [RunName '_soilwp.dat'], 1, stime, etime);
    end
    
    if(exist('watrbal.out','file')==2)
        FileTruncating('watrbal.out',   [RunName '_watbl.dat'], 2, stime, etime);
    end
   
        
    % save ascii-format outputs (weekly)
    if(exist('biowk.out','file')==2)
        FileTruncating('biowk.out',     [RunName '_biowk.dat'], 1, stime, etime);
    end
    if(exist('livecwk.out','file')==2)
        FileTruncating('livecwk.out',   [RunName '_livecwk.dat'], 1, stime, etime);
    end
    if(exist('deadcwk.out','file')==2)
        FileTruncating('deadcwk.out',   [RunName '_deadcwk.dat'], 1, stime, etime);
    end
    if(exist('mresp.out','file')==2)
        FileTruncating('mresp.out',     [RunName '_mresp.dat'], 1, stime, etime);
    end
    if(exist('soilcwk.out','file')==2)
        FileTruncating('soilcwk.out',   [RunName '_soilcwk.dat'], 1, stime, etime);
    end
    if(exist('summary.out','file')==2)
        FileTruncating('summary.out',   [RunName '_summary.dat'], 1, stime, etime);
    end

% save ascii-format outputs (monthly/yearly)
FileTruncating('Cstock.lis',[RunName '_Cstock.dat'], 2, stime, etime);
FileTruncating('Nstock.lis',[RunName '_Nstock.dat'], 2, stime, etime);
FileTruncating('Cflow.lis', [RunName '_Cflow.dat'], 2, stime, etime);
FileTruncating('Nflow.lis', [RunName '_Nflow.dat'], 2, stime, etime);
disp('I am ok4');

%***********************************************************
%read aglivc for biomass sorghum at harvest or maximum yield from RunName_Cstock.dat file
fid = fopen('Bioenergy_Cstock.dat','r');
biomassdata = textscan(fid,'%s','whitespace','\b\t','delimiter','\r', 'headerlines', 1);
biomassdata = cell2mat(biomassdata{1});
biomassdata = str2num(biomassdata);
abgbiomass = max(biomassdata(:,2));
fclose(fid);
disp(['Biomassyield: ' num2str(abgbiomass)]);


% Create an excel data file for figure for soil moisture prediction
fid = fopen('Bioenergy_soilwv.dat','r');
biomassdata_Figure = textscan(fid,'%s','whitespace','\b\t','delimiter','\r');
biomassdata_Figure = cell2mat(biomassdata_Figure{1});
biomassdata_Figure = str2num(biomassdata_Figure);
biomassdata_Figure = biomassdata_Figure(2:size(biomassdata_Figure, 1),:);
xlswrite('OutPutDataforDDC.xls', biomassdata_Figure, 'Soil Moisture', 'B2');
fclose(fid);

% Create an excel data file for figure for biomass prediction
fid = fopen('Bioenergy_Cstock.dat','r');
biomassdata_Figure = textscan(fid,'%s','whitespace','\b\t','delimiter','\r', 'headerlines', 1);
biomassdata_Figure = cell2mat(biomassdata_Figure{1});
biomassdata_Figure = str2num(biomassdata_Figure);
biomassdata_FigureB = biomassdata_Figure(:,1:2);
fclose(fid);


dos 'del *.bin';
dos 'del *.lis';
return;





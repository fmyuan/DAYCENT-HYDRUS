% Run DailyDayCent model and get the outputs

% By Fugen Dou, Texas A&M AgriLife at Beaumont
% September 14, 2012

function [abgbiomass, timeconsumed, biomassdata_FigureB] = DailyDayCent(RunName, stime, etime) 

% Input1: 

% Before running DailyDayCent.m function to make sure that you have the following input data files (17)ready: 
% crop.100 ; cult.100;  site.100 ; site.sch ; fert.100 ; fire.100 ;
% fix.100 ;  graz.100 ; harv.100 ; irri.100 ; omad.100 ; tree.100 ;
% trem.100 ; site.wth ;
% outfiles.in ; sitepar.in ; soils.in
% switchcondition: how to create a new crop file, change some parameters or
% add a new crop?
% RunName: the name of your run for. For example, it is for Biomass sorghum or College Station.
% jjj: the column number of crop to be added into crop.100 from input excel file
% stime: the starting time to read in data for analysis
% etime: the ending time to read in data for analysis
% Example: [abgbiomass, timeconsumed] = DailyDayCent('Bioenergy', 2008, 2009, 'F2') 

% To clear any XXX.bin or xxx.lis files to avoid any error for runing DailyDayCent model.
tic; % start to count the time
disp(dir('*.bin'));
disp(dir('*.lis'));
dos 'del *.bin';
dos 'del *.lis';

%*****Create a set of input data files for DailyDayCent *****************
%InPutForDailyDayCent(ObjectCrop);
% jjj: the column number of crop to be added into crop.100 from input excel file
%[num, txt, raw] = InPutForDailyDayCent(ObjectCrop, switchcondition, cropjjj);

% Run DailyDayCent
dos 'DailyDayCent -s CSBiomassSorghum2012New -n example';
%dos 'DailyDayCent -s example -n example';
disp('I am ok2');
    

% Extract DailyDayCent Simulation Results
[abgbiomass, biomassdata_FigureB] = DDCOutput(RunName, stime, etime) ;


timeconsumed = toc;
%--------------------------------------------------------------------
'Done!' %#ok<NOPTS>





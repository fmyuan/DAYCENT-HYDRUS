% Generating a new set of input data files to run DailyDayCent model

% By Fugen Dou, Texas AgriLife at Beaumont
% September 25, 2011


function [abgbiomass, timeconsumed, biomassdata_Figure] = DayCentCropSensitivityAnalysis(ObjectCrop, crop100modification, RunName, stime, etime)

%Example: [abgbiomass, timeconsumed, biomassdata_Figure, cropparameter] = DayCentCropSensitivityAnalysis('KNZ', 'change some parameters', 'SA', 2008, 2009)

PathOfExcelDataFile = 'C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab';
ExcelDataFile = 'InPutDataForDDC.xls';
ExcelSheet = 'crop';
%ObjectCrop = 'KNZ';
cropjjj = 4;


DateRangeA = 'G4:AV5'; %AV111
[num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRangeA);
DateRangeB = num;
biomassdata_Figure = [];


for jj = 1: size(DateRangeB,1)   
    
        DateRange = [DateRangeB(jj,1) DateRangeB(jj,21)*0.5];
        CropForSA(ObjectCrop, crop100modification, cropjjj, DateRange);
        [abgbiomass, timeconsumed, biomassdata_FigureB] = DailyDayCent(RunName, stime, etime); 
        biomassdata_Figure = [biomassdata_Figure biomassdata_FigureB];
        
         
    
end

xlswrite('OutPutDataforDDC.xls', biomassdata_Figure, 'Biomass', 'F2');




% Trucating DAYCENT output records for specific years
%
function [textdata]=FileTruncating(infile, outfile, n, yrstart, yrend)
% infile: input file to be extracted for data
% outfile: output dat file
% n: how many title and empty lines to be removed
% yrstart: starting year to read the data
% yrend: ending year to read data
% read infile
fid = 3;
fid = fopen(infile,'r');
textdata = textscan(fid,'%s','whitespace', ' \b\t','delimiter','\r');
fclose(fid);

%{,
%-------------------------------------------------------------------------
%write outfile
fid = 4; 
fid = fopen(outfile,'w'); 

% Read the text titles
for iline=1:n
    newtext = char(textdata{1,1}(iline,:));
    fprintf(fid, '%s\r\n', newtext); 
end

%beinning to read data
for iline=(n+1):size(textdata{1,1},1)
    newtext = char(textdata{1,1}(iline,:));
    ttext=textscan(newtext,'%f',1); %To convert string to double type by Fugen;
    tindex=floor(ttext{1,1});
    if (tindex>=yrstart && tindex<=yrend)
         fprintf(fid, '%s\r\n', newtext); 
    end
end

fclose(fid);
%
%--------------------------------------------------------------------------
%
%}

% Generating a new set of input data files to run DailyDayCent model

% By Fugen Dou, Texas AgriLife at Beaumont
% September 25, 2011


function [num, txt, raw] =InPutCult100ForDailyDayCent(ObjectCrop, crop100modification, cropjjj)
PathOfExcelDataFile = 'C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab';
ExcelDataFile = 'InPutDataForDDC.xls';
% Input1: 

% Input data files (17) for driving DailyDayCent Model includes: 
% crop.100 ; cult.100;  site.100 ; site.sch ; fert.100 ; fire.100 ;
% fix.100 ;  graz.100 ; harv.100 ; irri.100 ; omad.100 ; tree.100 ;
% trem.100 ; site.wth ;
% outfiles.in ; sitepar.in ; soils.in
% Example: [num, txt, raw] =InPutCrop100ForDailyDayCent('KNZ', 'change some parameters', 20)
% Example of "ObjectCrop": KNZ
% Example of "MatrixOfParameterToBeModified": [1 1.2; 2 32; 5 46]
    
 
%*****Create a new crop.100 fiel for optimization purpose by Dou on Sept 10, 2012*******************
% To create a MC sampling strategy:        
        NumOfTotalCropPar= 108;

        switch crop100modification

            case 'change some parameters'

                InitialCrop100File = 'crop100.txt';
                ExcelSheet = 'crop';
                DateRange = 'F1:AV111';
                [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRange);
                MatrixOfParameterToBeModified = num;
                disp(MatrixOfParameterToBeModified);
                disp(size(MatrixOfParameterToBeModified));
                disp(txt);
                disp(size(txt));
                disp(raw);
                disp(size(raw));
                TargertCropFile = 'crop.100';

                for i = 1:length(MatrixOfParameterToBeModified)
                    ParOfCropToChange = MatrixOfParameterToBeModified(i, 1);
                    ModifedValueOfCropPar = MatrixOfParameterToBeModified(i, 6);
                    %Crop100ForDailyDC(InitialCrop100File, ObjectCrop, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                    Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop,cropjjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                end


            case 'add a new crop'

                InitialCrop100File = 'crop.100';
                ExcelSheet = 'crop';
                DateRange = 'F1:AV111';
                [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRange);
                MatrixOfParameterToBeModified = num;
                ObjectCrop = raw;

                disp(MatrixOfParameterToBeModified);
                disp(size(MatrixOfParameterToBeModified));
                disp(txt);
                disp(size(txt));
                disp(raw);
                disp(size(raw));
                TargertCropFile = 'cropuseless.txt'; %which one will not be used

                %for i = 1:length(MatrixOfParameterToBeModified)
                    ParOfCropToChange = MatrixOfParameterToBeModified(1, 1);%which one will not be used
                    ModifedValueOfCropPar = MatrixOfParameterToBeModified(1, cropjjj);%which one will not be used
                    %Crop100ForDailyDC(InitialCrop100File, ObjectCrop, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                    Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop, cropjjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                %end

            otherwise
                
                disp('Crop.100: using the existed crop.100');
                num = 123;
                txt = 'using the existed crop.100';
                raw = 999;

        end
        

%**************************************************************************


%*****Create a new cult.100 fiel for optimization purpose by Dou on Sept 28, 2012*******************
% To create a MC sampling strategy:
%{
if exist('cult.100')== 2
    
    disp('Cult.100: using the existed cult.100');
    num = 123;
    txt = 'using the existed cult.100';
    raw = 999;
    
else
        InitialCrop100File = 'cult100.txt';
        NumOfTotalCropPar= 11;

        switch crop100modification

            case 'change some parameters'

                ExcelSheet = 'cult';
                DateRange = 'F1:M14';
                [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRange);
                MatrixOfParameterToBeModified = num;
                disp(MatrixOfParameterToBeModified);
                disp(size(MatrixOfParameterToBeModified));
                disp(txt);
                disp(size(txt));
                disp(raw);
                disp(size(raw));
                TargertCropFile = 'cult.100';

                for i = 1:length(MatrixOfParameterToBeModified)
                    ParOfCropToChange = MatrixOfParameterToBeModified(i, 1);
                    ModifedValueOfCropPar = MatrixOfParameterToBeModified(i, 6);
                    %Crop100ForDailyDC(InitialCrop100File, ObjectCrop, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                    Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop,jjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                end


            case 'add a new cultivation option'

                InitialCrop100File = 'cult.100';
                ExcelSheet = 'cult';
                DateRange = 'F1:M14';
                [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRange);
                MatrixOfParameterToBeModified = num;
                ObjectCrop = raw;

                disp(MatrixOfParameterToBeModified);
                disp(size(MatrixOfParameterToBeModified));
                disp(txt);
                disp(size(txt));
                disp(raw);
                disp(size(raw));
                TargertCropFile = 'cropuseless.txt'; %which one will not be used

                %for i = 1:length(MatrixOfParameterToBeModified)
                    ParOfCropToChange = MatrixOfParameterToBeModified(1, 1);%which one will not be used
                    ModifedValueOfCropPar = MatrixOfParameterToBeModified(1, jjj);%which one will not be used
                    %Crop100ForDailyDC(InitialCrop100File, ObjectCrop, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                    Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop, jjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
                %end

            otherwise

                disp('do something else');

        end
        
end      

%**************************************************************************


%*****Create a new soils.in fiel for optimization purpose by Dou on Sept 14, 2012*******************
% You have to modify the following arguments:
%ExcelDataFile = 'InPutDataForDDC.xls';
if exist('soils.in')== 2
    
    disp('soils.in: using the existed soils.in');
    
else
        ExcelSheet = 'soils.in';
        DateRange = 'B2:N10';
        SoilsIn(PathOfExcelDataFile, ExcelDataFile, ExcelSheet, DateRange);

end


%*****Create a new Site.wth for optimization purpose by Dou on Sept 14, 2012*******************
% Tips to prepare weather data file: 
    % 1. the first four columns should be in the format of integer
    % 2. the left columns should be in one scientific digit.
% You have to modify the following arguments:
%ExcelDataFile = 'InPutDataForDDC.xls';
if exist('weather.wth')== 2
    
    disp('weather.wth: using the existed weather.wth');
    
else

    ExcelSheet = 'weather';
    DateRange = 'AP2:AV19725'; %DateRange = 'A2:L8767'
    weather(PathOfExcelDataFile, ExcelDataFile, ExcelSheet, DateRange);

end
%}


% Create a new soils.in fiel to run DailyDayCent model

% By Fugen Dou, Texas A&M AgriLife at Beaumont
% September 14, 2012


function [num, txt, raw] = SoilsIn(SoilsInCondition, DataRange)
% PathOfExcelDataFile: Full path to read the excel data file which stored all input data for organization
% ExcelDataFile: Name of excel data file
% ExcelSheet: Name of the specified excel sheet
% DateRange: The range of data matrix to be read in
% Example: SoilsIn('C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab', 'InPutDataForDDC.xls', 'soils.in', 'B13:N26')
% Example: [num, txt, raw] = SoilsIn('CreateANewSoilsInFile', 'B13:N26')

%*****Create a new soils.in fiel for optimization purpose by Dou on Sept 12, 2012*******************
PathOfExcelDataFile = 'C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab';
ExcelDataFile = 'InPutDataForDDC.xls';
ExcelSheet = 'soils.in';
%DateRange = 'B2:N10';  %DateRange = 'B13:N26';

switch SoilsInCondition
    
    case 'CreateANewSoilsInFile'
        
        [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet, DataRange);
        RowOfExcelDataRange = size(num, 1);
        ColOfExcelDataRange = size(num, 2);
        fidsoils = fopen('RawSoils.in', 'w');
        %fprintf(fidsoils, '%5.5f %5.5f %5.5f %5.5f %5.5f %5.5f %5.5f %5.5f %5.5f %5.5f %5.5f %5.5f %5.5f\r\n', num');
        fprintf(fidsoils, '%f %f %f %f %f %f %f %f %f %f %f %f %f\r\n', num');
        fclose(fidsoils);
        
        %Organize the format of the soils.in file
        fidSoilsIn1 = fopen('RawSoils.in');
        fidSoilsIn2 = fopen('soils.in', 'w');
        
        for kk = 1:RowOfExcelDataRange
            
            for jj =1:(ColOfExcelDataRange-1)
                soilsvalue = textscan(fidSoilsIn1, '%f', 1, 'delimiter', '\b\t');
                numvalue = cell2mat(soilsvalue);
                fprintf(fidSoilsIn2, '%s', [num2str(numvalue,'%f') blanks(12-numel(num2str(fix(numvalue))))]);
            end
            soilsvalue2 = textscan(fidSoilsIn1, '%f', 1);
            numvalue2 =cell2mat(soilsvalue2);
            fprintf(fidSoilsIn2, '%s\r\n', [num2str(numvalue2,'%f') blanks(12-numel(num2str(fix(numvalue2))))]);
            
        end
        
        
        fclose(fidSoilsIn1);
        fclose(fidSoilsIn2);
        
    otherwise
        
        disp('using the exist soils.in file');
        num = 999;
        txt = 'using the existed soils.in file';
        raw = 999;
        
end
% Generating a new set of input data files to run DailyDayCent model

% By Fugen Dou, Texas AgriLife at Beaumont
% September 25, 2011


function [CropFullNameCell, CropFullNameChar] = cropparameter(ObjectCrop, crop100modification, cropjjj)
PathOfExcelDataFile = 'C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab';
ExcelDataFile = 'InPutDataForDDC.xls';
% Input1: 

% Input data files (17) for driving DailyDayCent Model includes: 
% crop.100 ; cult.100;  site.100 ; site.sch ; fert.100 ; fire.100 ;
% fix.100 ;  graz.100 ; harv.100 ; irri.100 ; omad.100 ; tree.100 ;
% trem.100 ; site.wth ;
% outfiles.in ; sitepar.in ; soils.in
% Example: [CropFullNameCell, CropFullNameChar] =  cropparameter('KNZ', 'change some parameters', 20)
    
 
%*****Create a new crop.100 fiel for optimization purpose by Dou on Sept 10, 2012*******************
% To identify whether there is the same crop used in the crop.100 file: 
InitialCrop100File = 'Copy of crop.100';
NumOfTotalCropPar = 108;

fid2 = fopen(InitialCrop100File); % Open this file to modify for crop.100 file
while(~feof(fid2))% To test whether it is the end of the file
    
    CropNameA = textscan(fid2, '%s',1); % Only read one whole line (row)
    CropFullNameCell = textscan(fid2, '%s',1, 'delimiter','\r'); % Only read one whole line (row)
    
    CropFullNameChar =char(CropFullNameCell{1,1});
    
    for j = 1:NumOfTotalCropPar % NumOfTotalCropPar: number of total crop parameters used in crop.100 file
        
        numvalue=textscan(fid2,'%f',1);% Read the value of the parameter
        %numvalue =cell2mat(numvalue);
        strvalueB=textscan(fid2,'%s',1);
        %strvalue=char(strvalueB{1});
        %fprintf(fid4,'%s',[num2str(numvalue,'%6.5f') blanks(12-numel(num2str(fix(numvalue))))]);
        %fprintf(fid4,'%s\r\n',strvalue);
        
    end
    
    
end

fclose(fid2);



%{

NumOfTotalCropPar= 108;

switch crop100modification
    
    case 'change some parameters'
        
        InitialCrop100File = 'crop100.txt';
        ExcelSheet = 'crop';
        DateRange = 'F1:AV111';
        [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRange);
        MatrixOfParameterToBeModified = num;
        disp(MatrixOfParameterToBeModified);
        disp(size(MatrixOfParameterToBeModified));
        disp(txt);
        disp(size(txt));
        disp(raw);
        disp(size(raw));
        TargertCropFile = 'crop.100';
        
        for i = 1:length(MatrixOfParameterToBeModified)
            ParOfCropToChange = MatrixOfParameterToBeModified(i, 1);
            ModifedValueOfCropPar = MatrixOfParameterToBeModified(i, 6);
            %Crop100ForDailyDC(InitialCrop100File, ObjectCrop, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
            Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop,cropjjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
        end
        
        
    case 'add a new crop'
        
        InitialCrop100File = 'crop.100';
        ExcelSheet = 'crop';
        DateRange = 'F1:AV111';
        [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRange);
        MatrixOfParameterToBeModified = num;
        ObjectCrop = raw;
        
        disp(MatrixOfParameterToBeModified);
        disp(size(MatrixOfParameterToBeModified));
        disp(txt);
        disp(size(txt));
        disp(raw);
        disp(size(raw));
        TargertCropFile = 'cropuseless.txt'; %which one will not be used
        
        %for i = 1:length(MatrixOfParameterToBeModified)
        ParOfCropToChange = MatrixOfParameterToBeModified(1, 1);%which one will not be used
        ModifedValueOfCropPar = MatrixOfParameterToBeModified(1, cropjjj);%which one will not be used
        %Crop100ForDailyDC(InitialCrop100File, ObjectCrop, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
        Crop100ForDailyDC(crop100modification, InitialCrop100File, ObjectCrop, cropjjj, NumOfTotalCropPar,ParOfCropToChange, ModifedValueOfCropPar, TargertCropFile);
        %end
        
    otherwise
        
        disp('Crop.100: using the existed crop.100');
        num = 123;
        txt = 'using the existed crop.100';
        raw = 999;
        
end
        
%}
%**************************************************************************



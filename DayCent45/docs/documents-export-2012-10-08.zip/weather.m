% Create a new soils.in fiel to run DailyDayCent model

% By Fugen Dou, Texas A&M AgriLife at Beaumont
% September 14, 2012


function [num, txt, raw] = weather(weathercondition, DataRange)
% PathOfExcelDataFile: Full path to read the excel data file which stored all input data for organization
% ExcelDataFile: Name of excel data file
% ExcelSheet: Name of the specified excel sheet
% DateRange: The range of data matrix to be read in
% Example: weather('C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab', 'InPutDataForDDC.xls', 'weather', 'A2:L8767')

%*****Create a new soils.in fiel for optimization purpose by Dou on Sept 12, 2012*******************
PathOfExcelDataFile = 'C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab';
ExcelDataFile = 'InPutDataForDDC.xls';
ExcelSheet = 'weather';
%DateRange = 'AP2:AV19725'; 

switch weathercondition
    
    case 'CreateANewWeatherFile'
        
        [num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet, DataRange);
        RowOfExcelDataRange = size(num, 1);
        ColOfExcelDataRange = size(num, 2);
        fidsoils = fopen('Rawweather.wth', 'w');
        fprintf(fidsoils, '%u %u %u %u %f %f %f %f %f %f %f %f\r\n', num');
        fclose(fidsoils);

        %Organize the format of the soils.in file
        fidSoilsIn1 = fopen('Rawweather.wth');
        fidSoilsIn2 = fopen('weather.wth', 'w');

        for kk = 1:(RowOfExcelDataRange-1)

            for jj =1:4
                soilsvalue = textscan(fidSoilsIn1, '%u', 1, 'delimiter', '\b\t');
                numvalue = cell2mat(soilsvalue);
                fprintf(fidSoilsIn2, '%s', [num2str(numvalue,'%d') blanks(6-numel(num2str(fix(numvalue))))]);
            end
            for jj =5:(ColOfExcelDataRange-1)
                soilsvalue = textscan(fidSoilsIn1, '%f', 1, 'delimiter', '\b\t');
                numvalue = cell2mat(soilsvalue);
                fprintf(fidSoilsIn2, '%s', [num2str(numvalue,'%-7.2f') blanks(6-numel(num2str(fix(numvalue))))]);
            end
                soilsvalue2 = textscan(fidSoilsIn1, '%f', 1);
                numvalue2 =cell2mat(soilsvalue2);
                fprintf(fidSoilsIn2, '%s\r\n', [num2str(numvalue2,'%-7.2f') blanks(6-numel(num2str(fix(numvalue2))))]); 

        end

            for jj =1:4
                soilsvalue = textscan(fidSoilsIn1, '%u', 1, 'delimiter', '\b\t');
                numvalue = cell2mat(soilsvalue);
                fprintf(fidSoilsIn2, '%s', [num2str(numvalue,'%d') blanks(6-numel(num2str(fix(numvalue))))]);
            end
            for jj =5:(ColOfExcelDataRange-1)
                soilsvalue = textscan(fidSoilsIn1, '%f', 1, 'delimiter', '\b\t');
                numvalue = cell2mat(soilsvalue);
                fprintf(fidSoilsIn2, '%s', [num2str(numvalue,'%-7.2f') blanks(6-numel(num2str(fix(numvalue))))]);
            end
                soilsvalue2 = textscan(fidSoilsIn1, '%f', 1);
                numvalue2 =cell2mat(soilsvalue2);
                fprintf(fidSoilsIn2, '%s', num2str(numvalue2)); 
                %fprintf(fidSoilsIn2, '%s', [num2str(numvalue2,'%-7.2f') blanks(6-numel(num2str(fix(numvalue2))))]);

        fclose(fidSoilsIn1);
        fclose(fidSoilsIn2);
        
    otherwise 
        
        disp('using the exist weather file');
        num = 999;
        txt = 'using the existed weather file';
        raw = 999;
        
end
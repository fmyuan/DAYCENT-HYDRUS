% Generating a new set of input data files to run DailyDayCent model

% By Fugen Dou, Texas AgriLife at Beaumont
% September 25, 2011


function  wrapcropforSA(ObjectCrop, crop100modification, IdofCrop, RunName, stime, etime)

% IdofCrop: ID number of crop to be changed in the input excelsheet file.
%Example: [abgbiomass, timeconsumed] = wrapcropforSA('SORG', 'change some parameters', 21, 'Bioenergy', 2008, 2009)

PathOfExcelDataFile = 'C:\Documents and Settings\Administrator\My Documents\Models\NewDailyDayCent_Matlab';
ExcelDataFile = 'InPutDataForDDC.xls';
ExcelSheet = 'crop';
IdofCrop = IdofCrop + 1;
cropjjj = 4;

DateRangeA = 'G4:AV110'; %AV111
[num, txt, raw] = xlsread([PathOfExcelDataFile '\' ExcelDataFile], ExcelSheet,DateRangeA);
%DateRangeB = num;
DateRangeB = num([1,2,3,4,5,9],:);
%DateRangeB = DateRangeB([83,84],:);
%DateRangeB = DateRangeB(83,:);
disp('The changed parameter matrix is: ');
disp(num2str(DateRangeB(:,[1,IdofCrop])));
cropparameterA = [];
biomassdata = [];

copyfile('crop.100', 'copyofInitialcrop100.txt', 'f');


for jj = 1: size(DateRangeB,1)   
    
        DateRange = [DateRangeB(jj,1) DateRangeB(jj,IdofCrop)*0.5];
        disp(['The changed parameter is: ' num2str(DateRangeB(jj,1)) '__' num2str(DateRangeB(jj,IdofCrop)*0.5)]);
        [cropparameter] = CropForSA(ObjectCrop, crop100modification, cropjjj, DateRange);
        [abgbiomass, timeconsumed, biomassdata_FigureA] = DailyDayCent(RunName, stime, etime); 
        cropparameterA = [cropparameterA cropparameter'];
        biomassdata_FigureA = [biomassdata_FigureA; ones((24-size(biomassdata_FigureA,1)),size(biomassdata_FigureA,2))*(-999)];
        biomassdata = [biomassdata biomassdata_FigureA];
        
        DateRange = [DateRangeB(jj,1) DateRangeB(jj,IdofCrop)*1];
        disp(['The changed parameter is: ' num2str(DateRangeB(jj,1)) '__' num2str(DateRangeB(jj,IdofCrop)*0.5)]);
        [cropparameter] = CropForSA(ObjectCrop, crop100modification, cropjjj, DateRange);
        [abgbiomass, timeconsumed, biomassdata_FigureB] = DailyDayCent(RunName, stime, etime); 
        cropparameterA = [cropparameterA cropparameter'];
        biomassdata_FigureB = [biomassdata_FigureB; ones((24-size(biomassdata_FigureB,1)),size(biomassdata_FigureB,2))*(-999)];
        biomassdata = [biomassdata biomassdata_FigureB];
        
        DateRange = [DateRangeB(jj,1) DateRangeB(jj,IdofCrop)*1.5];
        disp(['The changed parameter is: ' num2str(DateRangeB(jj,1)) '__' num2str(DateRangeB(jj,IdofCrop)*0.5)]);
        [cropparameter] = CropForSA(ObjectCrop, crop100modification, cropjjj, DateRange);
        [abgbiomass, timeconsumed, biomassdata_FigureC] = DailyDayCent(RunName, stime, etime); 
        cropparameterA = [cropparameterA cropparameter'];
        biomassdata_FigureC = [biomassdata_FigureC; ones((24-size(biomassdata_FigureC,1)),size(biomassdata_FigureC,2))*(-999)];
        biomassdata = [biomassdata biomassdata_FigureC];
        
end

xlswrite('OutPutDataforDDC.xls', cropparameterA, 'cropparameter', 'U2');
xlswrite('OutPutDataforDDC.xls', biomassdata, 'Biomass', 'AQ2');
delete('copyofInitialcrop100.txt');
 delete('*.csv');
 delete('*.out');




